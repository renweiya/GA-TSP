function [chromc,chromd]=liucrossover(chroma,chromb,tspdist)
%%%Ⱦɫ�彻�档
nn=length(chroma);
chroma=circshift(chroma',ceil(rand(1)*4))';
chromc=zeros(1,nn);
chromc(1)=chroma(1);
for i=2:nn,
    k=1;
    while k>0,
        am=(find(chroma==chromc(i-1))+k);
        bm=(find(chromb==chromc(i-1))+k);
        if am>nn,
            if mod(am,nn)~=0,
                am=mod(am,nn);
            else 
                am=nn;
            end
        end
        if bm>nn,
            if mod(bm,nn)~=0,
                bm=mod(bm,nn);
            else 
                bm=nn;
            end
        end
        if tspdist(chromc(i-1),chroma(am))<=tspdist(chromc(i-1),chromb(bm)),
            if isempty(find(chromc([1:i-1])==chroma(am))),
                chromc(i)=chroma(am); k=0;
            elseif isempty(find(chromc([1:i-1])==chromb(bm))),
                chromc(i)=chromb(bm); k=0;
            else 
                k=k+1;
            end
        else 
            if isempty(find(chromc([1:i-1])==chromb(bm))),
                chromc(i)=chromb(bm); k=0;
            elseif isempty(find(chromc([1:i-1])==chroma(am))),
                chromc(i)=chroma(am); k=0;
            else 
                k=k+1;
            end
        end
    end
end
chromd=chroma;
chroma=chromb;
chromb=chromd;
chromd(1)=chroma(1);
for i=2:nn,
    k=1;
    while k>0,
        am=(find(chroma==chromd(i-1))+k);
        bm=(find(chromb==chromd(i-1))+k);
        if am>nn,
            if mod(am,nn)~=0,
                am=mod(am,nn);
            else 
                am=nn;
            end
        end
        if bm>nn,
            if mod(bm,nn)~=0,
                bm=mod(bm,nn);
            else 
                bm=nn;
            end
        end
        if tspdist(chromd(i-1),chroma(am))<=tspdist(chromd(i-1),chromb(bm)),
            if isempty(find(chromd([1:i-1])==chroma(am))),
                chromd(i)=chroma(am); k=0;
            elseif isempty(find(chromd([1:i-1])==chromb(bm))),
                chromd(i)=chromb(bm); k=0;
            else 
                k=k+1;
            end
        else 
            if isempty(find(chromd([1:i-1])==chromb(bm))),
                chromd(i)=chromb(bm); k=0;
            elseif isempty(find(chromd([1:i-1])==chroma(am))),
                chromd(i)=chroma(am); k=0;
            else 
                k=k+1;
            end
        end
    end
end