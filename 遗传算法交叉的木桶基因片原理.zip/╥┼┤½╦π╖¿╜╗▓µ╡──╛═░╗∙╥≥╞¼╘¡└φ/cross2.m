function [child1,child2]=cross2(parent1,parent2,pc)
%Non-ABEL���淽��

if(rand(1)<pc)
    for i=1:length(parent1)
        child1(i)=parent1(parent2(i));
        child2(i)=parent2(parent1(i));
    end
else child1=parent1;
     child2=parent2;
end