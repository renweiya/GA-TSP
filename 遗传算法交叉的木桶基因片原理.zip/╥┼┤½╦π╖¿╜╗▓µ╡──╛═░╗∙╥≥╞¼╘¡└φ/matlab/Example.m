%TSP
% 
tic
    n = 30;
    xy = 100*rand(n,2);
    %load xy.mat xy;
    %xy=xy(1:n,:);
    pop_size = 2*n;
    num_iter = 1e4;
    show_prog = 1;
    show_res = 1;
    a = meshgrid(1:n);
    dmat = reshape(sqrt(sum((xy(a,:)-xy(a',:)).^2,2)),n,n);
    [opt_rte,min_dist] = tsp_ga(xy,dmat,pop_size,num_iter,show_prog,show_res)
toc