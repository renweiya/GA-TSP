function  t= pathlenfit(p,distmatrix)

 l=length(p);
 s=0;
for i=1:l-1
    s=s+distmatrix(p(i),p(i+1));
end
plength=distmatrix(p(1),p(end))+s;
fitness=1/plength;
t=[plength,fitness];
    